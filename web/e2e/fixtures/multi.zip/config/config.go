package config

const Version = "1.0"

var DefaultName = "multi"

type Config struct {
	Name string
	Port int
}

func Load() *Config {
	return &Config{Name: DefaultName, Port: 8080}
}
