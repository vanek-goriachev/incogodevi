package main

import (
	"example.com/multi/api"
	"example.com/multi/config"
)

func main() {
	cfg := config.Load()
	srv := api.NewServer(cfg)
	_ = srv.Run()
}
