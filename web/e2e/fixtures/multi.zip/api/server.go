package api

import (
	"example.com/multi/config"
	"example.com/multi/util"
)

const DefaultPort = 8080

var ErrNoConfig = errString("config required")

type errString string

func (e errString) Error() string { return string(e) }

type Server struct {
	Cfg  *config.Config
	port int
}

type Handler interface {
	Handle()
}

type EchoHandler struct{}

func (EchoHandler) Handle() {}

type JSONHandler struct{}

func (JSONHandler) Handle() {}

func NewServer(cfg *config.Config) *Server {
	return &Server{Cfg: cfg, port: DefaultPort}
}

func (s *Server) Run() error {
	if s.Cfg == nil {
		return ErrNoConfig
	}
	util.Log("server started")
	return nil
}
