package util

var Prefix = "[multi]"

func Log(msg string) {
	_ = Prefix + " " + msg
}

// Unused is dead code on purpose so the dead-code path has data too.
func Unused() string { return "noop" }
