package main

import "fmt"

func main() {
    fmt.Println("hello, T18")
}
