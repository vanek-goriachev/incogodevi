package main

import "fmt"

func main() {
    fmt.Println("missing go.mod")
}
