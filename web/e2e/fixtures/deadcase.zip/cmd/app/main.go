// Command app is the entry-point for the dead-code fixture used in T23
// browser tests. Importing the `used` package keeps everything reachable
// through Greet -> Greeter.Hello, while the sibling `dead` package stays
// orphan and lights up the dead-code report. We deliberately avoid stdlib
// imports so the analyzer stays under the auto-aggregation threshold.
package main

import "example.com/deadcase/used"

var Result string

func main() {
	Result = used.Greet("world")
}
