module example.com/deadcase

go 1.22
